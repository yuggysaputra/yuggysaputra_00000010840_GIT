import { Component } from '@angular/core';
import { PageSecondPage } from '../page-second/page-second';


@Component({
    selector: 'page-sign-in',
    templateUrl: 'first_page.html',
})

export class FirstPage{
    secondPage = PageSecondPage;

    constructor(){

    }
    
}

