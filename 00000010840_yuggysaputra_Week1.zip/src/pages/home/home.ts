import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FirstPage } from '../first_page/first_page';



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  firstPage = FirstPage;

  constructor() {

  }
  

}
